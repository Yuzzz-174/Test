package ahmed2z;

public class TestGit {
	public static void main(String[] args) {
		System.out.println("Hello World");
	}
}
